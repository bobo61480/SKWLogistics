#!/usr/bin/env bash
# Installs the Inventory Control patch into SKWLogistics-Full.
# Usage:  ./apply.sh [/path/to/SKWLogistics-Full]
set -euo pipefail

REPO="${1:-$HOME/SKWLogistics-Full}"
HERE="$(cd "$(dirname "$0")" && pwd)"

[ -f "$REPO/src/config/sources.js" ] || { echo "✗ $REPO doesn't look like SKWLogistics-Full (src/config/sources.js missing)"; exit 1; }

STAMP="$(date +%Y%m%d-%H%M%S)"
BK="$REPO/.inventory-patch-backup-$STAMP"
mkdir -p "$BK/src/config" "$BK/src/lib" "$BK/src/components"
cp "$REPO/src/config/sources.js"        "$BK/src/config/"
cp "$REPO/src/lib/fetchers.js"          "$BK/src/lib/"
cp "$REPO/src/App.jsx"                  "$BK/src/"
cp "$REPO/src/components/SyncStrip.jsx" "$BK/src/components/"
cp "$REPO/src/styles.css"               "$BK/src/"
echo "• Backed up originals to $BK"

install -m 644 "$HERE/src/config/sources.js"              "$REPO/src/config/sources.js"
install -m 644 "$HERE/src/lib/fetchers.js"                "$REPO/src/lib/fetchers.js"
install -m 644 "$HERE/src/lib/parsers/inventory.js"       "$REPO/src/lib/parsers/inventory.js"
install -m 644 "$HERE/src/components/InventoryPanel.jsx"  "$REPO/src/components/InventoryPanel.jsx"
install -m 644 "$HERE/src/components/SyncStrip.jsx"       "$REPO/src/components/SyncStrip.jsx"
install -m 644 "$HERE/src/App.jsx"                        "$REPO/src/App.jsx"
echo "• Copied 6 source files"

if grep -q "Inventory Control panel" "$REPO/src/styles.css"; then
  echo "• styles.css already contains the inventory block — skipped"
else
  cat "$HERE/styles-inventory-append.css" >> "$REPO/src/styles.css"
  echo "• Appended inventory styles to src/styles.css"
fi

echo
echo "✓ Patch applied. Next:"
echo "    cd $REPO && npm run dev     # verify locally, then build/deploy as usual"
echo
echo "  NOTE: 재고 및 구매 현황 (PURCHASE) is domain-restricted. Until it is shared"
echo "  as “Anyone with the link · Viewer”, its card shows a sharing hint and the"
echo "  sync strip flags PURCHASE ✕ — everything else loads normally."
