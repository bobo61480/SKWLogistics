import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  MASTER_ID, NATIONALS_ID, WMS_ID, INVENTORY_ID, PURCHASE_ID,
  MASTER_URL, NATIONALS_URL, WMS_URL, INVENTORY_URL, PURCHASE_URL,
  INBOUND_LINKED, IMPORTS, OUTBOUND, NATIONALS, WMS, EXCLUSIONS,
  INVENTORY, PURCHASE,
  KPI_ENDPOINT, REFRESH_MS, FINISHED, SOURCE_TYPES, DEPARTMENTS,
} from "./config/sources.js";
import { fetchGviz, fetchCsv, fetchJson, fetchAllSettled } from "./lib/fetchers.js";
import { loadDocumentIndex } from "./lib/documents.js";
import { indexImports, parseImportParcels } from "./lib/parsers/imports.js";
import { parseInboundLinked } from "./lib/parsers/inboundLinked.js";
import { parseOutbound } from "./lib/parsers/outbound.js";
import { parseNationals } from "./lib/parsers/nationals.js";
import { parseWmsSales } from "./lib/parsers/wmsSales.js";
import { parseExclusions } from "./lib/parsers/exclusions.js";
import { parseInventorySnapshot, parsePurchaseAllocation } from "./lib/parsers/inventory.js";
import { writeStatus } from "./lib/statusClient.js";
import { todayLA, dayKey } from "./lib/dates.js";
import { sourceClass, departmentClass } from "./lib/carriers.js";
import SyncStrip from "./components/SyncStrip.jsx";
import KpiPanel from "./components/KpiPanel.jsx";
import InventoryPanel from "./components/InventoryPanel.jsx";
import ImportTable from "./components/ImportTable.jsx";
import ScheduleBoard from "./components/ScheduleBoard.jsx";
import ParcelPanel from "./components/ParcelPanel.jsx";

export default function App() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sourceErrors, setSourceErrors] = useState({});
  const [kpis, setKpis] = useState(null);
  const [inventory, setInventory] = useState(null);
  const [purchase, setPurchase] = useState(null);
  const [lastSync, setLastSync] = useState(null);
  const [nextCheck, setNextCheck] = useState(null);
  const [query, setQuery] = useState("");
  const [showFinished, setShowFinished] = useState(false);
  const [savingId, setSavingId] = useState("");
  const [toast, setToast] = useState("");
  const [token, setToken] = useState(() => sessionStorage.getItem("plannerToken") ?? "");
  const inFlight = useRef(false);
  const lastRun = useRef(0);

  const days = useMemo(() => {
    const start = todayLA();
    return Array.from({ length: 14 }, (_, i) => {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      return d;
    });
  }, []);

  /* FIX #1 — every source loads independently; one slow/broken source can
     no longer blank the whole board. The two inventory workbooks join the
     same contract: they render when they answer, and report themselves in
     the sync strip when they don't. */
  const sync = useCallback(async () => {
    if (inFlight.current) return;
    inFlight.current = true;
    setLoading(true);
    try {
      await loadDocumentIndex(); // best-effort; never blocks

      const { results, errors } = await fetchAllSettled({
        inboundLinked: () => fetchGviz(MASTER_ID, INBOUND_LINKED),
        imports:       () => fetchCsv(MASTER_ID, IMPORTS.gid),
        outbound:      () => fetchCsv(MASTER_ID, OUTBOUND.gid),
        nationals:     () => fetchGviz(NATIONALS_ID, NATIONALS),
        wms:           () => fetchGviz(WMS_ID, WMS),
        inventory:     () => fetchGviz(INVENTORY_ID, INVENTORY),
        purchase:      () => fetchGviz(PURCHASE_ID, PURCHASE),
        exclusions:    () => (EXCLUSIONS.gid == null
                              ? Promise.resolve(null)
                              : fetchGviz(MASTER_ID, EXCLUSIONS)),
        kpis:          () => fetchJson(KPI_ENDPOINT),
      });

      const importsIndex = results.imports ? indexImports(results.imports) : [];
      const excluded = results.exclusions ? parseExclusions(results.exclusions) : new Set();
      const next = [
        ...(results.inboundLinked ? parseInboundLinked(results.inboundLinked, importsIndex) : []),
        ...(results.imports ? parseImportParcels(results.imports) : []),
        ...(results.outbound ? parseOutbound(results.outbound, excluded) : []),
        ...(results.nationals ? parseNationals(results.nationals) : []),
        ...(results.wms ? parseWmsSales(results.wms) : []),
      ];
      setItems(next);
      if (results.kpis) setKpis(results.kpis);
      if (results.inventory) setInventory(parseInventorySnapshot(results.inventory));
      if (results.purchase) setPurchase(parsePurchaseAllocation(results.purchase));
      setSourceErrors(errors);
      const now = new Date();
      lastRun.current = now.getTime();
      setLastSync(now);
      setNextCheck(new Date(now.getTime() + REFRESH_MS));
    } finally {
      inFlight.current = false;
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    sync();
    const wake = () => {
      if (document.visibilityState === "visible" && Date.now() - lastRun.current >= REFRESH_MS) sync();
    };
    const interval = window.setInterval(sync, REFRESH_MS);
    document.addEventListener("visibilitychange", wake);
    window.addEventListener("focus", wake);
    return () => {
      window.clearInterval(interval);
      document.removeEventListener("visibilitychange", wake);
      window.removeEventListener("focus", wake);
    };
  }, [sync]);

  const visible = useMemo(() => {
    const first = days[0].getTime();
    const last = days[days.length - 1].getTime();
    const q = query.trim().toLowerCase();
    return items.filter((e) => {
      const t = new Date(e.date.getFullYear(), e.date.getMonth(), e.date.getDate()).getTime();
      if (t < first || t > last) return false;
      if (!showFinished && FINISHED.has(String(e.status).toLowerCase())) return false;
      if (!q) return true;
      return [
        e.title, e.reference, e.secondary, e.status, e.sourceSheet, e.customerNo, e.po,
        e.invoice, e.shipmentNo, e.container, e.carrier, e.carrierReference,
        e.trackingNumber, e.mode, e.vessel, e.pod, e.eta, e.shippingMethod,
        e.sourceType, e.department,
      ].join(" ").toLowerCase().includes(q);
    });
  }, [days, items, query, showFinished]);

  const inbound = useMemo(() => visible.filter((e) => e.direction === "inbound"), [visible]);
  const inboundFreight = useMemo(() => inbound.filter((e) => !e.isSmallParcel), [inbound]);
  const inboundParcels = useMemo(() => inbound.filter((e) => e.isSmallParcel), [inbound]);
  const outboundTrucking = useMemo(
    () => visible.filter((e) => e.direction === "outbound" && !e.isSmallParcel && /^trucking$/i.test(e.shippingMethod ?? "")),
    [visible],
  );
  const outboundParcels = useMemo(() => visible.filter((e) => e.direction === "outbound" && e.isSmallParcel), [visible]);

  const totals = useMemo(() => {
    const today = dayKey(days[0]);
    return {
      inbound: inbound.length,
      outbound: outboundTrucking.length + outboundParcels.length,
      dueToday: visible.filter((e) => dayKey(e.date) === today).length,
      exceptions: visible.filter((e) => /pending|delay|hold|review/i.test(e.status)).length,
    };
  }, [days, inbound, outboundTrucking, outboundParcels, visible]);

  const onStatus = async (item, status) => {
    setSavingId(item.id);
    setToast("Saving " + item.title + "…");
    try {
      await writeStatus(item, status, token);
      setItems((prev) => prev.map((p) => (p.id === item.id ? { ...p, status } : p)));
      setToast(item.title + " updated to " + status + ".");
      window.setTimeout(() => setToast(""), 4500);
    } catch (err) {
      setToast(err instanceof Error ? err.message : "Status was not saved.");
    } finally {
      setSavingId("");
    }
  };

  const askToken = () => {
    const t = window.prompt("Operator token (required to save status changes back to the workbook):", token);
    if (t != null) {
      setToken(t.trim());
      sessionStorage.setItem("plannerToken", t.trim());
    }
  };

  return (
    <main className="site-shell">
      <header className="manifest">
        <div className="route-strip">
          <span>KRPUS ⚓ USLAX</span><i /><span>ICN ✈ LAX</span><i /><span>5609 RIVERWAY · BUENA PARK CA</span>
        </div>
        <div className="manifest-main">
          <div>
            <p className="eyebrow">LOGISTICS MASTER 2026 · LIVE WORKBOOK SYNC</p>
            <h1>StyleKorean<br />Logistics Hub</h1>
            <p className="intro">Every import, inbound delivery, trucking move, and small-parcel shipment across the next fourteen days—one operational board.</p>
          </div>
          <div className="manifest-actions">
            <button className="button primary" onClick={sync} disabled={loading}>
              {loading ? "SYNCING…" : "↻ REFRESH DATA"}
            </button>
            <div className="source-buttons" aria-label="Source workbooks">
              <a className="button secondary" href={MASTER_URL} target="_blank" rel="noreferrer">MASTER</a>
              <a className="button secondary" href={NATIONALS_URL} target="_blank" rel="noreferrer">NATIONAL</a>
              <a className="button secondary" href={WMS_URL} target="_blank" rel="noreferrer">SALES</a>
              <a className="button secondary" href={INVENTORY_URL} target="_blank" rel="noreferrer">INVENTORY</a>
              <a className="button secondary" href={PURCHASE_URL} target="_blank" rel="noreferrer">PURCHASE</a>
              <button className="button secondary" onClick={askToken} title="Set the operator token used for status writes">⚿ TOKEN</button>
            </div>
          </div>
        </div>
        <SyncStrip loading={loading} lastSync={lastSync} nextCheck={nextCheck} sourceErrors={sourceErrors} />
      </header>

      <section className="metrics" aria-label="Two-week schedule totals">
        <article><span>INBOUND</span><strong>{totals.inbound}</strong><small>arrivals in view</small></article>
        <article><span>OUTBOUND</span><strong>{totals.outbound}</strong><small>shipments in view</small></article>
        <article><span>DUE TODAY</span><strong>{totals.dueToday}</strong><small>combined moves</small></article>
        <article className={totals.exceptions ? "metric-alert" : ""}>
          <span>EXCEPTIONS</span><strong>{totals.exceptions}</strong><small>pending / hold / delayed</small>
        </article>
      </section>

      <KpiPanel kpis={kpis} error={sourceErrors.kpis} />

      <InventoryPanel
        inventory={inventory}
        purchase={purchase}
        errors={{ inventory: sourceErrors.inventory, purchase: sourceErrors.purchase }}
      />

      <section className="control-panel" aria-label="Schedule filters">
        <label className="search">
          <span>⌕</span>
          <input type="search" placeholder="Search shipment, customer, invoice, container, carrier…"
            value={query} onChange={(e) => setQuery(e.target.value)} />
        </label>
        <label className="finished-toggle">
          <input type="checkbox" checked={showFinished} onChange={(e) => setShowFinished(e.target.checked)} />
          Show completed entries
        </label>
      </section>

      <section className="source-legend" aria-label="Entry source colors">
        <strong>Mode &amp; carrier colors</strong>
        <div>{SOURCE_TYPES.map((t) => <span key={t} className={sourceClass(t)}><i aria-hidden="true" />{t}</span>)}</div>
      </section>
      <section className="source-legend department-legend" aria-label="Outbound department colors">
        <strong>Outbound departments</strong>
        <div>{DEPARTMENTS.map((d) => <span key={d} className={departmentClass(d)}><i aria-hidden="true" />{d}</span>)}</div>
      </section>

      <ImportTable items={inboundFreight} loading={loading} savingId={savingId} onStatus={onStatus} />

      <div className="schedule-stack" aria-label="Separate inbound and outbound schedules">
        <ScheduleBoard direction="inbound" days={days} items={inboundFreight} loading={loading} savingId={savingId} onStatus={onStatus} />
        <ParcelPanel direction="inbound" items={inboundParcels} loading={loading} savingId={savingId} onStatus={onStatus} />
        <ScheduleBoard direction="outbound" days={days} items={outboundTrucking} loading={loading} savingId={savingId} onStatus={onStatus} />
        <ParcelPanel direction="outbound" items={outboundParcels} loading={loading} savingId={savingId} onStatus={onStatus} />
      </div>

      <footer>
        <p><strong>SK</strong> STYLEKOREAN LOGISTICS · COMPANY OPERATIONS</p>
        <p className="mono">AUTO-REFRESH 30 MIN · STATUS EDITS SYNC TO SOURCE ROWS</p>
      </footer>
      {toast && <div className="toast" role="status">{toast}</div>}
    </main>
  );
}
