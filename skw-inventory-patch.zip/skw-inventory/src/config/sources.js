/**
 * SOURCE-OF-TRUTH CONFIG — every workbook ID, tab gid, read range and
 * column index used anywhere in the app lives HERE and only here.
 *
 * The previous build scattered these across a minified bundle; several
 * indexes had drifted from the live sheets (see /AUDIT.md). Each column
 * map below was verified against the live workbook headers on 2026-08-01.
 * Inventory workbooks (INVENTORY / PURCHASE) verified 2026-08-02.
 *
 * Column indexes are 0-based positions within the fetched RANGE.
 */

export const MASTER_ID = "1M-vZ24Yw4ZN7R7b_473cVn8kny8DznTakSsD3VQsCzc"; // LOGISTICS MASTER 2026
export const NATIONALS_ID = "12Aty04yiLPPqz06AFDM8Y1Log2jEOqdXDqwiUV5yVX8"; // NATIONAL/IHERB/MBX
export const WMS_ID = "14lH9SQzTLj8MR7UbxMfkoTDDlzhPoE8CqHV3IpK450I"; // WMS PROMOTION
export const INVENTORY_ID = "1tNBa7c78MGL3wBNwYsDdHcHnJZFcvxrLzn_M79vN4WY"; // 2026 재고 노출 현황 (warehouse exposure)
export const PURCHASE_ID = "17e5EYNMr3sTPhMfFVYBg3dQDC7CWxk2StwHzt_W55dY"; // 2026 재고 및 구매 현황 (purchase & channel allocation)

export const MASTER_URL = `https://docs.google.com/spreadsheets/d/${MASTER_ID}/edit`;
export const NATIONALS_URL = `https://docs.google.com/spreadsheets/d/${NATIONALS_ID}/edit?gid=99300389#gid=99300389`;
export const WMS_URL = `https://docs.google.com/spreadsheets/d/${WMS_ID}/edit?gid=0#gid=0`;
export const INVENTORY_URL = `https://docs.google.com/spreadsheets/d/${INVENTORY_ID}/edit`;
export const PURCHASE_URL = `https://docs.google.com/spreadsheets/d/${PURCHASE_ID}/edit`;

export const REFRESH_MS = 30 * 60 * 1000; // 30 min auto-sync
export const FETCH_TIMEOUT_MS = 12_000;   // FIX #1: every source fetch is bounded

/* ------------------------------------------------------------------ *
 *  MASTER · IMPORTS  (CSV export — wide sheet, banded status colors)
 *  Header row = sheet row 1; data begins row 2 (skip first 2 rows,
 *  matching legacy behavior; row 2 is the status legend band).
 * ------------------------------------------------------------------ */
export const IMPORTS = {
  gid: 1497250700,
  kind: "csv",
  firstDataRow: 3, // 1-based sheet row where real shipment rows begin
  col: {
    SHIPMENT: 0,   // A  SHIPMENT
    DOCS: 1,       // B  DOCS
    INVOICE: 2,    // C  INVOICE
    MBL: 3,        // D  MBL
    HBL: 4,        // E  HBL
    CONTAINER: 7,  // H  CONTAINER
    VSL: 14,       // O  VSL
    ETD: 15,       // P  ETD
    ETA: 16,       // Q  ETA
    LFD: 17,       // R  LFD
    DELIVERY: 18,  // S  DELIVERY EXPECTED
    STATUS: 29,    // AD WEBSITE STATUS (confirmed: write path re-reads AD)
  },
  statusA1Col: "AD",
};

/* ------------------------------------------------------------------ *
 *  MASTER · INBOUND SHIPMENTS DATA  (gviz JSON, headers on sheet row 3)
 *  VERIFIED live gviz labels, in order:
 *  0 Carrier Type · 1 Shipment # · 2 Docs/Folder · 3 Invoice · 4 MBL ·
 *  5 HBL · 6 Container · 7 FWS · 8 Entry Number · 9 Notes/Qty ·
 *  10 Vessel/Flight · 11 ETD · 12 ETA · 13 LFD · 14 Delivery Expected ·
 *  15 Reserved/Broker · 16 Inbound Status · 17 IMPORTS Source Row ·
 *  18 Source Link
 *
 *  FIX #2: the sheet already publishes the authoritative IMPORTS row in
 *  column R (index 17). The legacy client ignored it and re-derived the
 *  row by fuzzy matching — rows without a unique fuzzy match were
 *  silently DROPPED from the board. We now read col 17 first and only
 *  fall back to matching when it is blank; unmatched rows stay visible
 *  and are flagged UNLINKED instead of disappearing.
 * ------------------------------------------------------------------ */
export const INBOUND_LINKED = {
  gid: 2026070701,
  kind: "gviz",
  range: "A3:S1200",
  headers: 1,
  col: {
    CARRIER_TYPE: 0,
    SHIPMENT: 1,
    DOCS: 2,
    INVOICE: 3,
    MBL: 4,
    HBL: 5,
    CONTAINER: 6,
    FWS: 7,
    ENTRY: 8,
    NOTES: 9,
    VESSEL: 10,
    ETD: 11,
    ETA: 12,
    LFD: 13,
    DELIVERY: 14,
    BROKER: 15,
    STATUS: 16,
    IMPORTS_SOURCE_ROW: 17, // <- previously unused; now primary link key
    SOURCE_LINK: 18,
  },
};

/* ------------------------------------------------------------------ *
 *  MASTER · Outbound Shipping Schedule  (CSV export)
 *  Row 1 = banner, row 2 = summary formulas, row 3 = headers,
 *  data begins sheet row 4.
 *  VERIFIED header row:
 *  0 CUSTOMER · 1 INVOICE NO. · 2 ADDRESS · 3 SHIP DATE · 4 Pallet Type ·
 *  5 LENGTH · 6 WIDTH · 7 HEIGHT · 8 WEIGHT · 9 VOLUME · 10 CFT ·
 *  11 PCF · 12 DIM WEIGHT · 13 FREIGHT CLASS · 14 SUB CLASS · 15 NMFC ·
 *  16 CARRIER · 17 RATE · 18 PRO# · 19 NOTE · 20 STATUS · 21 SORT KEY ·
 *  22 (unlabeled WEBSITE STATUS mirror)
 *
 *  FIX #3: the legacy client read the mirror status from index 23
 *  (column X) which is EMPTY — the mirror actually lives at index 22
 *  (column W). It only "worked" by falling through to index 20. The
 *  write-confirmation had the same off-by-one (read U:X, took X first).
 *  We read STATUS (U, idx 20) as primary and the W mirror as secondary,
 *  and confirm writes against column U directly.
 * ------------------------------------------------------------------ */
export const OUTBOUND = {
  gid: 20260708,
  kind: "csv",
  firstDataRow: 4,
  col: {
    CUSTOMER: 0,
    INVOICE: 1,
    ADDRESS: 2,
    SHIP_DATE: 3,
    CARRIER: 16,
    RATE: 17,
    PRO: 18,
    NOTE: 19,
    STATUS: 20,        // U — authoritative
    SORT_KEY: 21,      // V
    STATUS_MIRROR: 22, // W — website mirror (was mis-read as X/23)
  },
  statusA1Col: "U",
};

/* ------------------------------------------------------------------ *
 *  NATIONALS · NATIONAL ORDER PROGRESS  (gviz JSON)
 *  VERIFIED: 0 Status · 1 Channel · 2 Dept · 3 PO# · 4 Amount ·
 *  5 (spacer) · 6 Order Date · 7 SSD · 8 CXL Date · 9 Pick up Date ·
 *  10 Routing · 11 Ship Via · 12 Remark
 *  KPI methodology: Amount = col E (4), Order Date = col G (6) — the
 *  on-page methodology note was correct; kept as-is.
 * ------------------------------------------------------------------ */
export const NATIONALS = {
  gid: 99300389,
  kind: "gviz",
  range: "A1:U3500",
  headers: 1,
  col: {
    STATUS: 0,
    CHANNEL: 1,
    DEPT: 2,
    PO: 3,
    AMOUNT: 4,
    ORDER_DATE: 6,
    SSD: 7,
    CXL_DATE: 8,
    PICKUP_DATE: 9,
    ROUTING: 10,
    SHIP_VIA: 11,
    REMARK: 12,
  },
};

/* ------------------------------------------------------------------ *
 *  WMS · Stylekorean  (gviz JSON, headers on sheet row 2)
 *  VERIFIED: 0 Date · 1 Invoice# · 2 Customer Name · 3 Sales ·
 *  4 Ship out Date · 5 SHIPPING METHOD · 6 INVOICE AMOUNT · 7 Issue? ·
 *  8.. tracking columns
 * ------------------------------------------------------------------ */
export const WMS = {
  gid: 0,
  kind: "gviz",
  range: "A2:AF4200",
  headers: 1,
  col: {
    DATE: 0,
    INVOICE: 1,
    CUSTOMER: 2,
    SALES_REP: 3,
    SHIP_OUT: 4,
    METHOD: 5,
    AMOUNT: 6,
    ISSUE: 7,
    TRACKING_FIRST: 8,
    TRACKING_COUNT: 24,
  },
};

/* ------------------------------------------------------------------ *
 *  INVENTORY · 2026 재고 노출 현황 · tab "CUR-LOC"  (gviz JSON)
 *  Live warehouse snapshot by SKU / rack location / expiry lot.
 *  Sharing: "Anyone with the link · Viewer" → client-side gviz works.
 *  VERIFIED headers (row 1):
 *  0 No. · 1 SKU · 2 Product Name · 3 Product BarCode · 4 Brand ·
 *  5 Location · 6 Expiry Date · 7 Total Qty · 8 Actual Qty ·
 *  9 Hold(picked) · 10 Hold(Req) · 11 Avail Qty
 *  Addressed by TAB NAME (gids in this workbook churn as per-shipment
 *  receiving tabs are added/removed weekly).
 * ------------------------------------------------------------------ */
export const INVENTORY = {
  sheet: "CUR-LOC",
  kind: "gviz",
  range: "A1:L8000",
  headers: 1,
  col: {
    NO: 0,
    SKU: 1,
    NAME: 2,
    BARCODE: 3,
    BRAND: 4,
    LOCATION: 5,
    EXPIRY: 6,
    TOTAL: 7,
    ACTUAL: 8,
    HOLD_PICKED: 9,
    HOLD_REQ: 10,
    AVAIL: 11,
  },
};

/* ------------------------------------------------------------------ *
 *  PURCHASE · 2026 재고 및 구매 현황  (gviz JSON, first tab)
 *  Purchase confirmations & channel allocation per SKU.
 *  VERIFIED headers (row 1):
 *  0 SKU · 1 Product Name · 2 Brand · 3 Barcode · 4 Cnfm Qty ·
 *  5 잔여수량 (remaining/unallocated) · 6 CAWH · 7 iHerb ·
 *  8 HQ iHerb PO · 9 National · 10 BK · 11 US_Official · 12 Moida ·
 *  13 NY · 14 Reference
 *  NOTE: this workbook is currently domain-restricted (stylekoreanus.com)
 *  — anonymous gviz returns 401 and the panel shows a sharing hint until
 *  it is switched to "Anyone with the link · Viewer" (or proxied via the
 *  server like /api/sales-kpis). No `sheet`/`gid` set → first tab.
 * ------------------------------------------------------------------ */
export const PURCHASE = {
  kind: "gviz",
  range: "A1:N2500",
  headers: 1,
  col: {
    SKU: 0,
    NAME: 1,
    BRAND: 2,
    BARCODE: 3,
    CNFM: 4,
    REMAINING: 5,
    CHANNEL_FIRST: 6, // CAWH … NY, in CHANNELS order below
  },
};
export const PURCHASE_CHANNELS = ["CAWH", "iHerb", "HQ iHerb PO", "National", "BK", "US_Official", "Moida", "NY"];

/* ------------------------------------------------------------------ *
 *  MASTER · OUTBOUND WEBSITE EXCLUSIONS
 *  FIX #8: this tab existed in the workbook but was never read by the
 *  legacy client. NOTE the tab stores SOURCE as "B2B/E-COM TRUCKING"
 *  while the actual tab is named "B2BE-COM TRUCKING" — we match by KEY
 *  only, so the name mismatch no longer matters (but should be fixed
 *  at source; see AUDIT.md §M-6).
 *  TODO: fill in the gid below (open the tab and copy #gid= from URL).
 * ------------------------------------------------------------------ */
export const EXCLUSIONS = {
  gid: 2026071701, // <- set me, then exclusions apply automatically
  kind: "gviz",
  range: "A1:C500",
  headers: 1,
  col: { SOURCE: 0, KEY: 1, REASON: 2 },
};

export const STATUS_ENDPOINT = "/api/status";
export const KPI_ENDPOINT = "/api/sales-kpis";
export const DOCS_ENDPOINT = "/api/documents"; // FIX #5: invoice→doc map no longer baked into the bundle

export const OUTBOUND_STATUSES = [
  "Scheduled", "Work in Progress", "Pending", "Shipping", "Shipped",
  "Delivered", "Received", "Cancelled", "Completed",
];
export const INBOUND_STATUSES = [
  ...OUTBOUND_STATUSES,
  "Customs Clearance", "FDA Review/Hold", "FWS Review/Hold", "Delayed",
];
export const FINISHED = new Set(["shipped", "delivered", "received", "cancelled", "completed"]);

export const SOURCE_TYPES = [
  "Wholesale", "Ocean", "Air", "UPS (Parcel)", "FedEx (Parcel)", "USPS",
  "Amazon", "DHL (Small Parcel)", "UPS (Freight)", "FedEx (Freight)", "DHL (Freight)",
];
export const DEPARTMENTS = ["Wholesale", "B2B/E-Com", "Nationals", "MBX", "NJ"];
