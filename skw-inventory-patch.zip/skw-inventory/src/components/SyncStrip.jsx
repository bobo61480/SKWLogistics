/** FIX #1 UI half: per-source health chips instead of one global spinner. */
export default function SyncStrip({ loading, lastSync, nextCheck, sourceErrors }) {
  const errNames = Object.keys(sourceErrors);
  const fmt = (d) => (d ? d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", timeZone: "America/Los_Angeles" }) : "—");
  const labels = {
    inboundLinked: "INBOUND", imports: "IMPORTS", outbound: "OUTBOUND",
    nationals: "NATIONALS", wms: "WMS", kpis: "KPI", exclusions: "EXCLUSIONS",
    docs: "DOCS", inventory: "INVENTORY", purchase: "PURCHASE",
  };
  return (
    <div className="sync-strip" role="status" aria-live="polite">
      <span>
        <b className={errNames.length ? "sync-dot error" : loading ? "sync-dot loading" : "sync-dot"} />
        {errNames.length
          ? errNames.length + " source" + (errNames.length > 1 ? "s" : "") + " need attention — everything else is live"
          : loading ? "Syncing live records…" : "5 live workbooks connected"}
      </span>
      {errNames.length > 0 && (
        <span className="source-chips">
          {errNames.map((n) => (
            <span key={n} className="source-chip error" title={sourceErrors[n]}>{labels[n] ?? n.toUpperCase()} ✕</span>
          ))}
        </span>
      )}
      <span className="mono">AUTO SYNC 30 MIN · LAST SYNC {fmt(lastSync)} · NEXT CHECK {fmt(nextCheck)}</span>
    </div>
  );
}
