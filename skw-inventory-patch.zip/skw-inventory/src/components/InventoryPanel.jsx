import { INVENTORY_URL, PURCHASE_URL } from "../config/sources.js";

const n0 = (v) => (v == null ? "—" : Math.round(v).toLocaleString("en-US"));
const pct = (part, whole) => (whole ? Math.round((part / whole) * 100) + "%" : "—");
const Num = ({ v }) => (v == null ? <strong className="kpi-skeleton">—</strong> : <strong>{n0(v)}</strong>);

function fmtExpiry(d) {
  if (!(d instanceof Date) || Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("en-US", { year: "numeric", month: "2-digit", day: "2-digit" });
}

/**
 * Inventory Control — two live cards:
 *  · CUR-LOC warehouse snapshot (재고 노출 현황) — units, holds, expiry risk
 *  · Purchase & channel allocation (재고 및 구매 현황) — confirmed vs 잔여수량
 * Each card degrades independently, same contract as the KPI panel.
 */
export default function InventoryPanel({ inventory, purchase, errors = {} }) {
  const inv = inventory ?? null;
  const pur = purchase ?? null;
  const riskUnits = inv ? inv.buckets.expired.units + inv.buckets.m6.units : null;

  return (
    <section className="kpi-panel inventory-panel" aria-labelledby="inventory-heading">
      <div className="kpi-heading">
        <div>
          <p className="eyebrow">2026 재고 · CUR-LOC SNAPSHOT + PURCHASE ALLOCATION</p>
          <h2 id="inventory-heading">Inventory Control</h2>
        </div>
        <span>{inv ? inv.rows + " LOTS · " + inv.locations + " LOCATIONS" : "LIVE"}</span>
      </div>

      {errors.inventory && <p className="kpi-error" role="alert">Inventory source unavailable: {errors.inventory}</p>}
      {errors.purchase && <p className="kpi-error" role="alert">Purchase source unavailable: {errors.purchase}</p>}

      <div className="kpi-grid inventory-grid">
        <article className="kpi-card inv-stock"><span>WAREHOUSE UNITS</span>
          <div><small>AVAILABLE</small><Num v={inv?.availQty} /></div>
          <div><small>ON HOLD</small><Num v={inv?.holdQty} /></div>
        </article>

        <article className="kpi-card inv-stock"><span>SKUS ON RACK</span>
          <strong>{inv ? n0(inv.skus) : "—"}</strong>
          <small>{inv ? n0(inv.totalQty) + " total units incl. holds" : "syncing…"}</small>
        </article>

        <article className={"kpi-card inv-expiry" + (riskUnits ? " inv-alert" : "")}><span>EXPIRY RISK · AVAIL UNITS</span>
          <div><small>EXPIRED</small><Num v={inv?.buckets.expired.units} /></div>
          <div><small>≤6 MO</small><Num v={inv?.buckets.m6.units} /></div>
          <div><small>6–12 MO</small><Num v={inv?.buckets.m12.units} /></div>
        </article>

        <article className="kpi-card inv-brands"><span>TOP BRANDS · AVAIL</span>
          {inv?.topBrands?.length ? (
            <ul className="inv-list">
              {inv.topBrands.map((b) => (
                <li key={b.brand}><em>{b.brand}</em><b>{n0(b.units)}</b></li>
              ))}
            </ul>
          ) : <strong className="kpi-skeleton">—</strong>}
        </article>

        <article className="kpi-card inv-purchase"><span>PURCHASE · CURRENT ROUND</span>
          <div><small>CONFIRMED</small><Num v={pur?.cnfmQty} /></div>
          <div><small>잔여 (UNALLOCATED)</small><Num v={pur?.remainingQty} /></div>
          <small>{pur ? pct(pur.remainingQty, pur.cnfmQty) + " of confirmed units still unassigned" : "syncing…"}</small>
        </article>

        <article className="kpi-card inv-channels"><span>CHANNEL ALLOCATION</span>
          {pur?.channels?.length ? (
            <ul className="inv-list">
              {pur.channels.filter((c) => c.units > 0).sort((a, b) => b.units - a.units).slice(0, 6).map((c) => (
                <li key={c.name}><em>{c.name}</em><b>{n0(c.units)}</b></li>
              ))}
            </ul>
          ) : <strong className="kpi-skeleton">—</strong>}
        </article>
      </div>

      {inv?.atRisk?.length > 0 && (
        <div className="inv-risk-table" role="table" aria-label="Shortest-dated lots with available units">
          <p className="inv-risk-title">SHORT-DATED LOTS (AVAILABLE UNITS)</p>
          {inv.atRisk.map((r) => (
            <p key={r.sku + r.location + String(r.days)} className="inv-risk-row">
              <b className={r.days != null && r.days < 0 ? "inv-expired" : ""}>{fmtExpiry(r.expiry)}</b>
              <span className="mono">{r.sku}</span>
              <span>{r.name}</span>
              <span className="mono">{r.location}</span>
              <b>{n0(r.avail)}</b>
            </p>
          ))}
        </div>
      )}

      <p className="kpi-method">
        Warehouse figures read the CUR-LOC tab of 재고 노출 현황 (SKU × location × expiry lot); hold =
        Hold(picked) + Hold(Req); expiry buckets count AVAILABLE units against today (Pacific). Purchase
        figures read the first tab of 재고 및 구매 현황: Cnfm Qty, 잔여수량 and the CAWH → NY channel split.
        Both refresh on the same 30-minute sync.{" "}
        <a href={INVENTORY_URL} target="_blank" rel="noreferrer">Open inventory source</a> ·{" "}
        <a href={PURCHASE_URL} target="_blank" rel="noreferrer">Open purchase source</a>.
      </p>
    </section>
  );
}
