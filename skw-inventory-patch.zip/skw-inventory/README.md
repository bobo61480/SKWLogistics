# Inventory Control patch — SKWLogistics-Full

Adds two live data sources to the Logistics Hub and a new **Inventory Control**
panel rendered directly under the KPI Control Tower:

| Source | Workbook | Tab | Access |
| --- | --- | --- | --- |
| INVENTORY | 2026 재고 노출 현황 | `CUR-LOC` (addressed by tab NAME — gids churn as receiving tabs are added) | public link ✓ works now |
| PURCHASE | 2026 재고 및 구매 현황 | first tab | domain-restricted ✗ shows a sharing hint until fixed |

## What the panel shows
- **Warehouse units** — Available vs On-hold (Hold picked + Hold req), SKU and location counts
- **Expiry risk** — AVAILABLE units already expired / ≤6 months / 6–12 months, plus a
  short-dated lot table (date · SKU · product · rack location · qty)
- **Top brands** by available units
- **Purchase round** — Cnfm Qty vs 잔여수량 (unallocated) with % unassigned
- **Channel allocation** — CAWH / iHerb / HQ iHerb PO / National / BK / US_Official / Moida / NY

Both sources join the existing 30-min auto-sync and fail independently
(SyncStrip chips: INVENTORY ✕ / PURCHASE ✕) without blanking the board.

## Files
- `src/config/sources.js` — REPLACES: adds INVENTORY / PURCHASE ids, urls, column maps
- `src/lib/fetchers.js` — REPLACES: fetchGviz now accepts `sheet` (tab name) and gives a
  clear 401/403 “share the sheet” error
- `src/lib/parsers/inventory.js` — NEW: snapshot + allocation aggregation
- `src/components/InventoryPanel.jsx` — NEW
- `src/components/SyncStrip.jsx` — REPLACES: new source labels, “5 live workbooks”
- `src/App.jsx` — REPLACES: fetch wiring, panel placement, INVENTORY/PURCHASE source buttons
- `styles-inventory-append.css` — APPENDED to `src/styles.css` by apply.sh

All replaced files are byte-identical to the repo versions as of 2026-08-02 except
for the additions — nothing else was touched.

## Install
```bash
unzip skw-inventory-patch.zip -d ~/skw-inventory-patch
cd ~/skw-inventory-patch && ./apply.sh ~/SKWLogistics-Full
cd ~/SKWLogistics-Full && npm run dev   # verify, then build/deploy as usual
```
`apply.sh` backs up every replaced file to `.inventory-patch-backup-<timestamp>/` first.

## Purchase workbook access — pick one
1. **Easiest:** in 재고 및 구매 현황 → Share → “Anyone with the link · Viewer”.
   (The exposure workbook is already shared this way.)
2. **Keep it restricted:** proxy it server-side like `/api/sales-kpis` and point the
   `purchase` task at the endpoint instead of `fetchGviz`.
Until then the card shows the hint and everything else loads normally.
